﻿using Alphtmost.Modelos;
using Alphtmost.Servicios.Interfaz;
using Alphtmost.Servicios.VistasModelos;
using AlphtmostAPI.Consumer;
using BCrypt.Net;
using Microsoft.AspNetCore.Mvc;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Text;

namespace Alphtmost.MVC.Controllers
{
    public class LoginController : Controller
    {
        private readonly IUsuarioClienteService _usuarioClienteService;
        private readonly IAdministradorService _administradorService;
        private readonly IArtistaClienteService _artistaClienteService;
        private readonly ISendGridClient _sendGridClient;

        public LoginController(
            IUsuarioClienteService usuarioClienteService,
            IAdministradorService administradorService,
            IArtistaClienteService artistaClienteService,
            ISendGridClient sendGridClient)
        {
            _usuarioClienteService = usuarioClienteService;
            _administradorService = administradorService;
            _artistaClienteService = artistaClienteService;
            _sendGridClient = sendGridClient;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(LoginViewModel modelLogin)
        {
            if (ModelState.IsValid)
            {
                // UsuarioCliente login directo
                var cliente = await _usuarioClienteService.GetByEmailAsync(modelLogin.Email);
                if (cliente != null && BCrypt.Net.BCrypt.Verify(modelLogin.Contraseña, cliente.ContraseñaHash))
                {
                    // Verifica el perfil por Id 
                    var perfil = cliente.Perfil;
                    if (perfil == null)
                        perfil = Crud<Perfil>.GetAll().FirstOrDefault(p => p.UsuarioClienteId == cliente.Id);

                    if (perfil == null)
                        return RedirectToAction("Create", "Perfiles", new { usuarioClienteId = cliente.Id });

                    return RedirectToAction("Index", "Home");
                }

                // ArtistaCliente login 
                var artistaCliente = await _artistaClienteService.GetByEmailAsync(modelLogin.Email);
                if (artistaCliente != null && BCrypt.Net.BCrypt.Verify(modelLogin.Contraseña, artistaCliente.ContraseñaHash))
                {
                    var perfil = artistaCliente.Perfil ?? Crud<Perfil>.GetAll().FirstOrDefault(p => p.ArtistaClienteId == artistaCliente.Id);
                    if (perfil == null)
                        return RedirectToAction("Create", "Perfiles", new { artistaClienteId = artistaCliente.Id });

                    var bibliografia = artistaCliente.Bibliografia ?? Crud<Bibliografia>.GetAll().FirstOrDefault(b => b.ArtistaClienteId == artistaCliente.Id);
                    if (bibliografia == null)
                        return RedirectToAction("Create", "Bibliografias", new { artistaClienteId = artistaCliente.Id });

                    var premios = bibliografia.Premios;
                    if (premios == null || !premios.Any())
                        return RedirectToAction("Create", "Premios", new { bibliografiaId = bibliografia.Id });

                    // Si todo está completo entonces confirmación por correo
                    var data = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{modelLogin.Email}|artista"));
                    var confirmationLink = Url.Action("ConfirmLogin", "Login", new { data }, Request.Scheme);

                    var emailMessage = new SendGridMessage()
                    {
                        From = new EmailAddress("alphtmostmusic@gmail.com", "Alphtmost Music"),
                        Subject = "Confirma tu inicio de sesión",
                        PlainTextContent = $"Haz clic en este enlace para confirmar tu inicio de sesión: {confirmationLink}",
                        HtmlContent = $"<p>Haz clic en este enlace para confirmar tu inicio de sesión: <a href='{confirmationLink}'>Confirmar login</a></p>"
                    };
                    emailMessage.AddTo(modelLogin.Email);
                    await _sendGridClient.SendEmailAsync(emailMessage);

                    return View("VerificarCorreoLogin");
                }

                // Administrador requiere confirmación por correo
                var admin = await _administradorService.GetByEmailAsync(modelLogin.Email);
                if (admin != null && BCrypt.Net.BCrypt.Verify(modelLogin.Contraseña, admin.ContraseñaHash))
                {
                    var data = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{modelLogin.Email}|admin"));
                    var confirmationLink = Url.Action("ConfirmLogin", "Login", new { data }, Request.Scheme);

                    var emailMessage = new SendGridMessage()
                    {
                        From = new EmailAddress("alphtmostmusic@gmail.com", "Alphtmost Music"),
                        Subject = "Confirma tu inicio de sesión",
                        PlainTextContent = $"Haz clic en este enlace para confirmar tu inicio de sesión: {confirmationLink}",
                        HtmlContent = $"<p>Haz clic en este enlace para confirmar tu inicio de sesión: <a href='{confirmationLink}'>Confirmar login</a></p>"
                    };
                    emailMessage.AddTo(modelLogin.Email);
                    await _sendGridClient.SendEmailAsync(emailMessage);

                    return View("VerificarCorreoLogin");
                }

                ModelState.AddModelError("", "Credenciales inválidas.");
            }

            return View(modelLogin);
        }

        public IActionResult ConfirmLogin(string data)
        {
            try
            {
                var decoded = Encoding.UTF8.GetString(Convert.FromBase64String(data));
                var parts = decoded.Split('|');
                if (parts.Length != 2)
                    throw new Exception("Datos inválidos.");
                return RedirectToAction("Index", "Home");
            }
            catch
            {
                TempData["Mensaje"] = "Error al confirmar el login.";
                return RedirectToAction("Index", "Login");
            }
        }

        [HttpGet]
        public IActionResult RecuperarPassword()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> RecuperarPassword(RecuperarPasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Buscar el usuario en los tres servicios
                var usuario = await _usuarioClienteService.GetByEmailAsync(model.Email);
                if (usuario != null)
                {
                    await EnviarEnlaceRecuperacion(model.Email, "usuario");
                    ViewBag.Message = "Revisa tu correo para restablecer tu contraseña.";
                    return View();
                }
                var artista = await _artistaClienteService.GetByEmailAsync(model.Email);
                if (artista != null)
                {
                    await EnviarEnlaceRecuperacion(model.Email, "artista");
                    ViewBag.Message = "Revisa tu correo para restablecer tu contraseña.";
                    return View();
                }
                var admin = await _administradorService.GetByEmailAsync(model.Email);
                if (admin != null)
                {
                    await EnviarEnlaceRecuperacion(model.Email, "admin");
                    ViewBag.Message = "Revisa tu correo para restablecer tu contraseña.";
                    return View();
                }
                ModelState.AddModelError("Email", "No existe una cuenta con ese correo.");
            }
            return View(model);
        }

        private async Task EnviarEnlaceRecuperacion(string email, string tipo)
        {
            var data = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{email}|{tipo}"));
            var link = Url.Action("NuevaPassword", "Login", new { data }, Request.Scheme);

            var emailMessage = new SendGridMessage()
            {
                From = new EmailAddress("alphtmostmusic@gmail.com", "Alphtmost Music"),
                Subject = "Recupera tu contraseña",
                PlainTextContent = $"Haz clic en este enlace para restablecer tu contraseña: {link}",
                HtmlContent = $"<p>Haz clic en este enlace para restablecer tu contraseña: <a href='{link}'>Restablecer contraseña</a></p>"
            };
            emailMessage.AddTo(email);
            await _sendGridClient.SendEmailAsync(emailMessage);
        }

        [HttpGet]
        public IActionResult NuevaPassword(string data)
        {
            var decoded = Encoding.UTF8.GetString(Convert.FromBase64String(data));
            var parts = decoded.Split('|');
            if (parts.Length != 2)
                return RedirectToAction("Index", "Login");

            var model = new NuevaPasswordViewModel
            {
                Email = parts[0],
                Tipo = parts[1]
            };
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> NuevaPassword(NuevaPasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                var hash = BCrypt.Net.BCrypt.HashPassword(model.NuevaContraseña);
                if (model.Tipo == "usuario")
                {
                    var usuario = await _usuarioClienteService.GetByEmailAsync(model.Email);
                    if (usuario != null)
                    {
                        usuario.ContraseñaHash = hash;
                        _usuarioClienteService.UpdateUsuario(usuario);
                        ViewBag.Message = "Contraseña actualizada correctamente.";
                        return RedirectToAction("Index", "Login");
                    }
                }
                else if (model.Tipo == "artista")
                {
                    var artista = await _artistaClienteService.GetByEmailAsync(model.Email);
                    if (artista != null)
                    {
                        artista.ContraseñaHash = hash;
                        _artistaClienteService.UpdateArtista(artista); // Cambia a UpdateArtista si tienes
                        ViewBag.Message = "Contraseña actualizada correctamente.";
                        return RedirectToAction("Index", "Login");
                    }
                }
                else if (model.Tipo == "admin")
                {
                    var admin = await _administradorService.GetByEmailAsync(model.Email);
                    if (admin != null)
                    {
                        admin.ContraseñaHash = hash;
                        _administradorService.UpdateAdministrador(admin); // Cambia a UpdateAdministrador si tienes
                        ViewBag.Message = "Contraseña actualizada correctamente.";
                        return RedirectToAction("Index", "Login");
                    }
                }
                ModelState.AddModelError("", "No se pudo actualizar la contraseña.");
            }
            return View(model);
        }
    }
}