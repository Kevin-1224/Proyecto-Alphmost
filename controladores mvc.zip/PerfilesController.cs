﻿using Alphtmost.Modelos;
using AlphtmostAPI.Consumer;
using Alphtmost.Servicios.Interfaz;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Alphtmost.MVC.Controllers
{
    public class PerfilesController : Controller
    {
        private readonly IFileUploader _fileUploader;

        public PerfilesController(IFileUploader fileUploader)
        {
            _fileUploader = fileUploader;
        }

        // GET: PerfilesController
        public ActionResult Index()
        {
            var data = Crud<Perfil>.GetAll();
            return View(data);
        }

        // GET: PerfilesController/Details/5
        public ActionResult Details(int id)
        {
            var data = Crud<Perfil>.GetById(id);
            return View(data);
        }

        // GET: PerfilesController/Create
        public ActionResult Create(int? usuarioClienteId, int? artistaClienteId, int? artistaId)
        {
            var perfil = new Perfil();

            if (usuarioClienteId.HasValue)
                perfil.UsuarioClienteId = usuarioClienteId.Value;
            if (artistaClienteId.HasValue)
                perfil.ArtistaClienteId = artistaClienteId.Value;
            if (artistaId.HasValue)
                perfil.ArtistaId = artistaId.Value;

            return View(perfil);
        }

        // POST: PerfilesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Perfil data, IFormFile imagenPerfil)
        {
            try
            {
                if (imagenPerfil != null && imagenPerfil.Length > 0)
                {
                    using var stream = imagenPerfil.OpenReadStream();
                    var url = await _fileUploader.UploadFileAsync(stream, imagenPerfil.FileName, imagenPerfil.ContentType);
                    data.ImagenPerfilUrl = url;
                }

                var perfilCreado = Crud<Perfil>.Create(data);

                // Si es artista cliente, redirige a crear bibliografía
                if (data.ArtistaClienteId != null)
                {
                    return RedirectToAction("Create", "Bibliografias", new { artistaClienteId = data.ArtistaClienteId });
                }

                // Si es usuario cliente, redirige a home
                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(data);
            }
        }

        // GET: PerfilesController/Edit/5
        public ActionResult Edit(int id)
        {
            var data = Crud<Perfil>.GetById(id);
            return View(data);
        }

        // POST: PerfilesController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, Perfil data, IFormFile imagenPerfil)
        {
            try
            {
                if (imagenPerfil != null && imagenPerfil.Length > 0)
                {
                    using var stream = imagenPerfil.OpenReadStream();
                    var url = await _fileUploader.UploadFileAsync(stream, imagenPerfil.FileName, imagenPerfil.ContentType);
                    data.ImagenPerfilUrl = url;
                }

                Crud<Perfil>.Update(id, data);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(data);
            }
        }

        // GET: PerfilesController/Delete/5
        public ActionResult Delete(int id)
        {
            var data = Crud<Perfil>.GetById(id);
            return View(data);
        }

        // POST: PerfilesController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(int id, Perfil data)
        {
            try
            {
                var perfil = Crud<Perfil>.GetById(id);

                // Elimina la imagen del bucket si existe
                if (!string.IsNullOrEmpty(perfil?.ImagenPerfilUrl))
                {
                    // Extrae el nombre del archivo de la URL
                    var fileName = perfil.ImagenPerfilUrl.Split('/').Last();
                    await _fileUploader.DeleteFileAsync(fileName);
                }

                Crud<Perfil>.Delete(id);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(data);
            }
        }
    }
}