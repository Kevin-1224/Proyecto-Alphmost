﻿using Alphtmost.Modelos;
using AlphtmostAPI.Consumer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Alphtmost.MVC.Controllers
{
    public class ArtistasController : Controller
    {
        // GET: ArtistasController
        public ActionResult Index()
        {

            var data = Crud<Artista>.GetAll();
            return View(data);
        }

        // GET: ArtistasController/Details/5
        public ActionResult Details(int id)
        {
            var data = Crud<Artista>.GetById(id);
            return View(data);
        }

        // GET: ArtistasController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ArtistasController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Artista data)
        {
            try
            {
                //var nombreAutor = collection["nombreAutor"];
                Crud<Artista>.Create(data);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(data);
            }
        }

        // GET: ArtistasController/Edit/5
        public ActionResult Edit(int id)
        {
            var data = Crud<Artista>.GetById(id);
            return View(data);
        }

        // POST: ArtistasController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Artista data)
        {
            try
            {
                Crud<Artista>.Update(id, data);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(data);
            }
        }

        // GET: ArtistasController/Delete/5
        public ActionResult Delete(int id)
        {
            var data = Crud<Artista>.GetById(id);
            return View(data);
        }

        // POST: ArtistasController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Artista data)
        {
            try
            {
                Crud<Artista>.Delete(id);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(data);
            }
        }
    }
}
