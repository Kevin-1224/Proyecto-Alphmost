﻿using Alphtmost.Modelos;
using AlphtmostAPI.Consumer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Alphtmost.MVC.Controllers
{
    public class BibliografiasController : Controller
    {
        // GET: BibliografiasController
        public ActionResult Index()
        {
            var data = Crud<Bibliografia>.GetAll();
            return View(data);
        }

        // GET: BibliografiasController/Details/5
        public ActionResult Details(int id)
        {
            var data = Crud<Bibliografia>.GetById(id);
            return View(data);
        }

        // GET: BibliografiasController/Create
        public ActionResult Create(int? artistaId, int? artistaClienteId)
        {
            var model = new Bibliografia();
            if (artistaId.HasValue)
                model.ArtistaId = artistaId.Value;
            if (artistaClienteId.HasValue)
                model.ArtistaClienteId = artistaClienteId.Value;
            return View(model);
        }

         // POST: BibliografiasController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Bibliografia data)
        {
            try
            {
                data.FechaNacimiento = DateTime.SpecifyKind(data.FechaNacimiento, DateTimeKind.Utc);
                var bibliografiaCreada = Crud<Bibliografia>.Create(data);

                // Enlazar la bibliografia al artista o artista cliente
                if (data.ArtistaId != null)
                {
                    var artista = Crud<Artista>.GetById(data.ArtistaId.Value);
                    artista.BibliografiaId = bibliografiaCreada.Id;
                    Crud<Artista>.Update(artista.Id, artista);
                }
                else if (data.ArtistaClienteId != null)
                {
                    var artistaCliente = Crud<ArtistaCliente>.GetById(data.ArtistaClienteId.Value);
                    artistaCliente.BibliografiaId = bibliografiaCreada.Id;
                    Crud<ArtistaCliente>.Update(artistaCliente.Id, artistaCliente);
                }
                return RedirectToAction("Details", "Bibliografias", new { id = bibliografiaCreada.Id });
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error al crear la bibliografía: {ex.Message}");
                return View(data);
            }
        }

        // GET: BibliografiasController/Edit/5
        public ActionResult Edit(int id)
        {
            var data = Crud<Bibliografia>.GetById(id);
            return View(data);
        }

        // POST: BibliografiasController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Bibliografia data)
        {
            try
            {
                data.FechaNacimiento = DateTime.SpecifyKind(data.FechaNacimiento, DateTimeKind.Utc);
                Crud<Bibliografia>.Update(id, data);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error al editar el artista: {ex.Message}");
                return View(data);
            }
        }

        // GET: BibliografiasController/Delete/5
        public ActionResult Delete(int id)
        {
            var data = Crud<Bibliografia>.GetById(id);
            return View(data);
        }

        // POST: BibliografiasController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Bibliografia Cliente)
        {
            try
            {
                Crud<Bibliografia>.Delete(id);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error al eliminar el artista: {ex.Message}");
                return View();
            }
        }
    }
}
