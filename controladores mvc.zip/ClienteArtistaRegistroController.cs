﻿using Alphtmost.Modelos;
using Alphtmost.Servicios.Implementacion;
using Alphtmost.Servicios.Interfaz;
using Alphtmost.Servicios.VistasModelos;
using Microsoft.AspNetCore.Mvc;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Text;

namespace Alphtmost.MVC.Controllers
{
    public class ClienteArtistaRegistroController : Controller
    {
        private readonly ServicioDeVerificacionCorreoCliente _servicioDeVerificacionCorreoCliente;
        private readonly ISendGridClient _sendGridClient;
        private readonly IArtistaClienteService _artistaClienteService;

        public ClienteArtistaRegistroController(
            ServicioDeVerificacionCorreoCliente servicioDeVerificacionCorreoCliente,
            ISendGridClient sendGridClient,
            IArtistaClienteService artistaClienteService)
        {
            _servicioDeVerificacionCorreoCliente = servicioDeVerificacionCorreoCliente;
            _sendGridClient = sendGridClient;
            _artistaClienteService = artistaClienteService;
        }
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ClienteArtistaRegistroViewModel model)
        {
            if (ModelState.IsValid)
            {
                bool emailRegistrado = await _servicioDeVerificacionCorreoCliente.IsEmailRegisteredAsync(model.Email);

                if (emailRegistrado)
                {
                    ModelState.AddModelError("Email", "Este correo ya está registrado en otra cuenta.");
                    return View(model);
                }

                // Serializa todos los campos necesarios
                var userData = Convert.ToBase64String(Encoding.UTF8.GetBytes(
                    $"{model.Nombre}|{model.Apellido}|{model.Email}|{model.Contraseña}|{model.FechaNacimiento:O}|{model.NombreArtistico}|{(int)model.GeneroMusical}"
                ));

                var confirmationLink = Url.Action("ConfirmEmail", "ClienteArtistaRegistro", new { data = userData }, Request.Scheme);

                var emailMessage = new SendGridMessage()
                {
                    From = new EmailAddress("alphtmostmusic@gmail.com", "Alphtmost Music"),
                    Subject = "Confirma tu correo electrónico",
                    PlainTextContent = $"Por favor, confirma tu correo haciendo click en este enlace: {confirmationLink}",
                    HtmlContent = $"<p>Por favor, confirma tu correo haciendo click en este enlace: <a href='{confirmationLink}'>Confirmar correo</a></p>"
                };
                emailMessage.AddTo(model.Email);

                try
                {
                    await _sendGridClient.SendEmailAsync(emailMessage);
                    return View("VerificarCorreo");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error al enviar el correo: {ex.Message}");
                    return View(model);
                }
            }

            return View(model);
        }

        public async Task<IActionResult> ConfirmEmail(string data)
        {
            try
            {
                var decoded = Encoding.UTF8.GetString(Convert.FromBase64String(data));
                var parts = decoded.Split('|');
                if (parts.Length != 7)
                    throw new Exception("Datos de confirmación inválidos.");

                var nombre = parts[0];
                var apellido = parts[1];
                var email = parts[2];
                var contraseña = parts[3];
                var fechaNacimiento = DateTime.Parse(parts[4]);
                var nombreArtistico = parts[5];
                var generoMusical = (Alphtmost.Enums.Enums.GeneroMusical)int.Parse(parts[6]);

                var existingUser = await _servicioDeVerificacionCorreoCliente.IsEmailRegisteredAsync(email);
                if (existingUser)
                {
                    ViewBag.Message = "Este correo ya está registrado.";
                    return RedirectToAction("Index", "Login");
                }

                var contraseñaHash = BCrypt.Net.BCrypt.HashPassword(contraseña);

                var newUser = new ArtistaCliente
                {
                    Email = email,
                    ContraseñaHash = contraseñaHash,
                    Nombre = nombre,
                    Apellido = apellido,
                    GeneroMusical = generoMusical,
                    NombreArtistico = nombreArtistico,
                    FechaNacimiento = fechaNacimiento
                };

                _artistaClienteService.CreateArtista(newUser);

                ViewBag.Message = "¡Correo confirmado exitosamente! Ahora puedes iniciar sesión.";
                return RedirectToAction("Index", "Login");
            }
            catch
            {
                ViewBag.Message = "Error al confirmar el correo. El enlace es inválido o ha expirado.";
                return View("Error");
            }
        }
    }
}
