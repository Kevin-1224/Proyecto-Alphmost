﻿using Alphtmost.Modelos;
using AlphtmostAPI.Consumer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Alphtmost.MVC.Controllers
{
    public class PremiosController : Controller
    {
        // GET: PremiosController
        public ActionResult Index()
        {
            var data = Crud<Premio>.GetAll();
            return View(data);
        }
        public ActionResult Details(int id)
        {
            var data = Crud<Premio>.GetById(id);
            return View(data);
        }

        // GET: PremiosController/Create
        public ActionResult Create(int bibliografiaId)
        {
            var model = new Premio { BibliografiaId = bibliografiaId };
            return View(model);
        }

        // POST: PremiosController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Premio data)
        {
            try
            {
                Crud<Premio>.Create(data);
                // Redirige a los detalles de la bibliografía para seguir agregando premios si se desea
                return RedirectToAction("Details", "Bibliografias", new { id = data.BibliografiaId });
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error al crear el premio: {ex.Message}");
                return View(data);
            }
        }

        // GET: PremiosController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: PremiosController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: PremiosController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: PremiosController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
