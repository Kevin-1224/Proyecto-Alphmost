﻿using Alphtmost.Modelos;
using AlphtmostAPI.Consumer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Alphtmost.MVC.Controllers
{
    public class ArtistasClientesController : Controller
    {
        // GET: ArtistasClientesController
        public ActionResult Index()
        {
            var data = Crud<ArtistaCliente>.GetAll();
            return View(data);
        }

        // GET: ArtistasClientesController/Details/5
        public ActionResult Details(int id)
        {
            var data  = Crud<ArtistaCliente>.GetById(id);
            return View(data);
        }

        // GET: ArtistasClientesController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ArtistasClientesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ArtistaCliente data)
        {
            try
            {
                data.FechaNacimiento = DateTime.SpecifyKind(data.FechaNacimiento, DateTimeKind.Utc);
                data.FechaRegistro = DateTime.SpecifyKind(data.FechaRegistro, DateTimeKind.Utc);
                Crud<ArtistaCliente>.Create(data);
                return RedirectToAction(nameof(Index));
            }
            catch(Exception ex)
            {
                ModelState.AddModelError("", $"Error al crear el artista: {ex.Message}");
                return View(data);
            }
            
        }

        // GET: ArtistasClientesController/Edit/5
        public ActionResult Edit(int id)
        {
            var data = Crud<ArtistaCliente>.GetById(id);
            return View(data);
        }

        // POST: ArtistasClientesController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, ArtistaCliente data)
        {
            try
            {
                data.FechaNacimiento = DateTime.SpecifyKind(data.FechaNacimiento, DateTimeKind.Utc);
                data.FechaRegistro = DateTime.SpecifyKind(data.FechaRegistro, DateTimeKind.Utc);
                Crud<ArtistaCliente>.Update(id, data);  
                return RedirectToAction(nameof(Index));
            }
            catch(Exception ex)
            {
                ModelState.AddModelError("", $"Error al editar el artista: {ex.Message}");
                return View(data);
            }
            
        }

        // GET: ArtistasClientesController/Delete/5
        public ActionResult Delete(int id)
        {
            var data = Crud<ArtistaCliente>.GetById(id);
            return View(data);
        }

        // POST: ArtistasClientesController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Artista Cliente)
        {
            try
            {
                Crud<ArtistaCliente>.Delete(id);
                return RedirectToAction(nameof(Index));
            }
            catch(Exception ex)
            {
                ModelState.AddModelError("", $"Error al eliminar el artista: {ex.Message}");
                return View();
            }
        }
    }
}
