﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Alphtmost.API.Migrations
{
    /// <inheritdoc />
    public partial class v1AlphtmostData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Administradores",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ContraseñaHash = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Administradores", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Bibliografias",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Biografia = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EstiloMusical = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Discografia = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FechaNacimiento = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PaisOrigen = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ArtistaId = table.Column<int>(type: "int", nullable: true),
                    ArtistaClienteId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bibliografias", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "GruposPremiums",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UsuarioClienteId = table.Column<int>(type: "int", nullable: false),
                    CodigoInvitacionUnico = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FechaCreacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TipoPlan = table.Column<int>(type: "int", nullable: false),
                    LimiteMiembros = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GruposPremiums", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PlanesPremiums",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TipoPlan = table.Column<int>(type: "int", nullable: false),
                    Precio = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PlanesPremiums", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Premios",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BibliografiaId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Premios", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Premios_Bibliografias_BibliografiaId",
                        column: x => x.BibliografiaId,
                        principalTable: "Bibliografias",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "UsuariosClientes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Apellido = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ContraseñaHash = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Genero = table.Column<int>(type: "int", nullable: false),
                    EsPremium = table.Column<bool>(type: "bit", nullable: false),
                    FechaNacimiento = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaRegistro = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaVencimientoPremium = table.Column<DateTime>(type: "datetime2", nullable: true),
                    GrupoPremiumId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UsuariosClientes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_UsuariosClientes_GruposPremiums_GrupoPremiumId",
                        column: x => x.GrupoPremiumId,
                        principalTable: "GruposPremiums",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "CodigosInvitaciones",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Codigo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UsuarioClienteId = table.Column<int>(type: "int", nullable: false),
                    FechaGeneracion = table.Column<DateTime>(type: "datetime2", nullable: true),
                    FechaExpiracion = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CodigosInvitaciones", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CodigosInvitaciones_UsuariosClientes_UsuarioClienteId",
                        column: x => x.UsuarioClienteId,
                        principalTable: "UsuariosClientes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Pagos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UsuarioClienteId = table.Column<int>(type: "int", nullable: false),
                    Monto = table.Column<double>(type: "float", nullable: false),
                    Estado = table.Column<int>(type: "int", nullable: false),
                    FechaPago = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PlanPremiumId = table.Column<int>(type: "int", nullable: true),
                    MetodoPago = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TokenPago = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pagos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Pagos_PlanesPremiums_PlanPremiumId",
                        column: x => x.PlanPremiumId,
                        principalTable: "PlanesPremiums",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Pagos_UsuariosClientes_UsuarioClienteId",
                        column: x => x.UsuarioClienteId,
                        principalTable: "UsuariosClientes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Perfiles",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NombrePerfil = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Descripcion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ImagenPerfilUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UsuarioClienteId = table.Column<int>(type: "int", nullable: true),
                    ArtistaClienteId = table.Column<int>(type: "int", nullable: true),
                    ArtistaId = table.Column<int>(type: "int", nullable: true),
                    Instagram = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Facebook = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Youtube = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Perfiles", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Perfiles_UsuariosClientes_UsuarioClienteId",
                        column: x => x.UsuarioClienteId,
                        principalTable: "UsuariosClientes",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Transacciones",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PagoId = table.Column<int>(type: "int", nullable: false),
                    EstadoTransaccion = table.Column<int>(type: "int", nullable: false),
                    FechaTransaccion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DetalleTransaccion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Monto = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Transacciones", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Transacciones_Pagos_PagoId",
                        column: x => x.PagoId,
                        principalTable: "Pagos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Artistas",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NombreArtistico = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    GeneroMusical = table.Column<int>(type: "int", nullable: false),
                    Descripcion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PerfilId = table.Column<int>(type: "int", nullable: true),
                    BibliografiaId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Artistas", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Artistas_Bibliografias_BibliografiaId",
                        column: x => x.BibliografiaId,
                        principalTable: "Bibliografias",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Artistas_Perfiles_PerfilId",
                        column: x => x.PerfilId,
                        principalTable: "Perfiles",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "ArtistasClientes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Apellido = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NombreArtistico = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    GeneroMusical = table.Column<int>(type: "int", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ContraseñaHash = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FechaNacimiento = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaRegistro = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PerfilId = table.Column<int>(type: "int", nullable: true),
                    BibliografiaId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ArtistasClientes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ArtistasClientes_Bibliografias_BibliografiaId",
                        column: x => x.BibliografiaId,
                        principalTable: "Bibliografias",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ArtistasClientes_Perfiles_PerfilId",
                        column: x => x.PerfilId,
                        principalTable: "Perfiles",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Seguidores",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UsuarioClienteId = table.Column<int>(type: "int", nullable: false),
                    FechaSeguimiento = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PerfilId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Seguidores", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Seguidores_Perfiles_PerfilId",
                        column: x => x.PerfilId,
                        principalTable: "Perfiles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Seguidores_UsuariosClientes_UsuarioClienteId",
                        column: x => x.UsuarioClienteId,
                        principalTable: "UsuariosClientes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Canciones",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Titulo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Estado = table.Column<int>(type: "int", nullable: false),
                    CancionUrl = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PropietariosDerechos = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    GeneroMusical = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FechaLanzamiento = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PortadaUrl = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UsuarioClienteId = table.Column<int>(type: "int", nullable: true),
                    ArtistaId = table.Column<int>(type: "int", nullable: true),
                    ArtistaClienteId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Canciones", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Canciones_ArtistasClientes_ArtistaClienteId",
                        column: x => x.ArtistaClienteId,
                        principalTable: "ArtistasClientes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Canciones_Artistas_ArtistaId",
                        column: x => x.ArtistaId,
                        principalTable: "Artistas",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "PlayLists",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UsuarioClienteId = table.Column<int>(type: "int", nullable: true),
                    ArtistaClienteId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PlayLists", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PlayLists_ArtistasClientes_ArtistaClienteId",
                        column: x => x.ArtistaClienteId,
                        principalTable: "ArtistasClientes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_PlayLists_UsuariosClientes_UsuarioClienteId",
                        column: x => x.UsuarioClienteId,
                        principalTable: "UsuariosClientes",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "PlayListsCanciones",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PlaylistId = table.Column<int>(type: "int", nullable: false),
                    CancionId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PlayListsCanciones", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PlayListsCanciones_Canciones_CancionId",
                        column: x => x.CancionId,
                        principalTable: "Canciones",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PlayListsCanciones_PlayLists_PlaylistId",
                        column: x => x.PlaylistId,
                        principalTable: "PlayLists",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Artistas_BibliografiaId",
                table: "Artistas",
                column: "BibliografiaId",
                unique: true,
                filter: "[BibliografiaId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Artistas_PerfilId",
                table: "Artistas",
                column: "PerfilId",
                unique: true,
                filter: "[PerfilId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_ArtistasClientes_BibliografiaId",
                table: "ArtistasClientes",
                column: "BibliografiaId",
                unique: true,
                filter: "[BibliografiaId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_ArtistasClientes_PerfilId",
                table: "ArtistasClientes",
                column: "PerfilId",
                unique: true,
                filter: "[PerfilId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Canciones_ArtistaClienteId",
                table: "Canciones",
                column: "ArtistaClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_Canciones_ArtistaId",
                table: "Canciones",
                column: "ArtistaId");

            migrationBuilder.CreateIndex(
                name: "IX_CodigosInvitaciones_UsuarioClienteId",
                table: "CodigosInvitaciones",
                column: "UsuarioClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_Pagos_PlanPremiumId",
                table: "Pagos",
                column: "PlanPremiumId");

            migrationBuilder.CreateIndex(
                name: "IX_Pagos_UsuarioClienteId",
                table: "Pagos",
                column: "UsuarioClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_Perfiles_UsuarioClienteId",
                table: "Perfiles",
                column: "UsuarioClienteId",
                unique: true,
                filter: "[UsuarioClienteId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_PlayLists_ArtistaClienteId",
                table: "PlayLists",
                column: "ArtistaClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayLists_UsuarioClienteId",
                table: "PlayLists",
                column: "UsuarioClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayListsCanciones_CancionId",
                table: "PlayListsCanciones",
                column: "CancionId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayListsCanciones_PlaylistId",
                table: "PlayListsCanciones",
                column: "PlaylistId");

            migrationBuilder.CreateIndex(
                name: "IX_Premios_BibliografiaId",
                table: "Premios",
                column: "BibliografiaId");

            migrationBuilder.CreateIndex(
                name: "IX_Seguidores_PerfilId",
                table: "Seguidores",
                column: "PerfilId");

            migrationBuilder.CreateIndex(
                name: "IX_Seguidores_UsuarioClienteId",
                table: "Seguidores",
                column: "UsuarioClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_Transacciones_PagoId",
                table: "Transacciones",
                column: "PagoId");

            migrationBuilder.CreateIndex(
                name: "IX_UsuariosClientes_GrupoPremiumId",
                table: "UsuariosClientes",
                column: "GrupoPremiumId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Administradores");

            migrationBuilder.DropTable(
                name: "CodigosInvitaciones");

            migrationBuilder.DropTable(
                name: "PlayListsCanciones");

            migrationBuilder.DropTable(
                name: "Premios");

            migrationBuilder.DropTable(
                name: "Seguidores");

            migrationBuilder.DropTable(
                name: "Transacciones");

            migrationBuilder.DropTable(
                name: "Canciones");

            migrationBuilder.DropTable(
                name: "PlayLists");

            migrationBuilder.DropTable(
                name: "Pagos");

            migrationBuilder.DropTable(
                name: "Artistas");

            migrationBuilder.DropTable(
                name: "ArtistasClientes");

            migrationBuilder.DropTable(
                name: "PlanesPremiums");

            migrationBuilder.DropTable(
                name: "Bibliografias");

            migrationBuilder.DropTable(
                name: "Perfiles");

            migrationBuilder.DropTable(
                name: "UsuariosClientes");

            migrationBuilder.DropTable(
                name: "GruposPremiums");
        }
    }
}
