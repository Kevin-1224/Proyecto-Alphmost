﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Alphtmost.Modelos;

    public class DbContext : Microsoft.EntityFrameworkCore.DbContext
    {
        public DbContext (DbContextOptions<DbContext> options)
            : base(options)
        {
        }

        public DbSet<Alphtmost.Modelos.Administrador> Administradores { get; set; } = default!;

        public DbSet<Alphtmost.Modelos.Artista> Artistas { get; set; } = default!;

        public DbSet<Alphtmost.Modelos.ArtistaCliente> ArtistasClientes { get; set; } = default!;

        public DbSet<Alphtmost.Modelos.Cancion> Canciones { get; set; } = default!;

        public DbSet<Alphtmost.Modelos.CodigoInvitacion> CodigosInvitaciones { get; set; } = default!;

        public DbSet<Alphtmost.Modelos.GrupoPremium> GruposPremiums { get; set; } = default!;

        public DbSet<Alphtmost.Modelos.PlayList> PlayLists { get; set; } = default!;

        public DbSet<Alphtmost.Modelos.Perfil> Perfiles { get; set; } = default!;

        public DbSet<Alphtmost.Modelos.Pago> Pagos { get; set; } = default!;

        public DbSet<Alphtmost.Modelos.PlayListCancion> PlayListsCanciones { get; set; } = default!;

        public DbSet<Alphtmost.Modelos.PlanPremium> PlanesPremiums { get; set; } = default!;

        public DbSet<Alphtmost.Modelos.Seguidor> Seguidores { get; set; } = default!;

        public DbSet<Alphtmost.Modelos.Transaccion> Transacciones { get; set; } = default!;

        public DbSet<Alphtmost.Modelos.UsuarioCliente> UsuariosClientes { get; set; } = default!;
        public DbSet<Alphtmost.Modelos.Bibliografia> Bibliografias  { get; set; } = default!;

        public DbSet<Alphtmost.Modelos.Premio> Premios { get; set; } = default!;
}
