﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Alphtmost.Modelos;

namespace Alphtmost.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlayListCancionesController : ControllerBase
    {
        private readonly DbContext _context;

        public PlayListCancionesController(DbContext context)
        {
            _context = context;
        }

        // GET: api/PlayListCanciones
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PlayListCancion>>> GetPlayListCancion()
        {
            return await _context.PlayListsCanciones.ToListAsync();
        }

        // GET: api/PlayListCanciones/5
        [HttpGet("{id}")]
        public async Task<ActionResult<PlayListCancion>> GetPlayListCancion(int id)
        {
            var playListCancion = await _context.PlayListsCanciones.FindAsync(id);

            if (playListCancion == null)
            {
                return NotFound();
            }

            return playListCancion;
        }

        // PUT: api/PlayListCanciones/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPlayListCancion(int id, PlayListCancion playListCancion)
        {
            if (id != playListCancion.Id)
            {
                return BadRequest();
            }

            _context.Entry(playListCancion).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PlayListCancionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/PlayListCanciones
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<PlayListCancion>> PostPlayListCancion(PlayListCancion playListCancion)
        {
            _context.PlayListsCanciones.Add(playListCancion);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPlayListCancion", new { id = playListCancion.Id }, playListCancion);
        }

        // DELETE: api/PlayListCanciones/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePlayListCancion(int id)
        {
            var playListCancion = await _context.PlayListsCanciones.FindAsync(id);
            if (playListCancion == null)
            {
                return NotFound();
            }

            _context.PlayListsCanciones.Remove(playListCancion);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool PlayListCancionExists(int id)
        {
            return _context.PlayListsCanciones.Any(e => e.Id == id);
        }
    }
}
