﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Alphtmost.Modelos;

namespace Alphtmost.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CodigosInvitacionesController : ControllerBase
    {
        private readonly DbContext _context;

        public CodigosInvitacionesController(DbContext context)
        {
            _context = context;
        }

        // GET: api/CodigosInvitaciones
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CodigoInvitacion>>> GetCodigoInvitacion()
        {
            return await _context.CodigosInvitaciones.ToListAsync();
        }

        // GET: api/CodigosInvitaciones/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CodigoInvitacion>> GetCodigoInvitacion(int id)
        {
            var codigoInvitacion = await _context.CodigosInvitaciones.FindAsync(id);

            if (codigoInvitacion == null)
            {
                return NotFound();
            }

            return codigoInvitacion;
        }

        // PUT: api/CodigosInvitaciones/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCodigoInvitacion(int id, CodigoInvitacion codigoInvitacion)
        {
            if (id != codigoInvitacion.Id)
            {
                return BadRequest();
            }

            _context.Entry(codigoInvitacion).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CodigoInvitacionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/CodigosInvitaciones
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<CodigoInvitacion>> PostCodigoInvitacion(CodigoInvitacion codigoInvitacion)
        {
            _context.CodigosInvitaciones.Add(codigoInvitacion);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCodigoInvitacion", new { id = codigoInvitacion.Id }, codigoInvitacion);
        }

        // DELETE: api/CodigosInvitaciones/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCodigoInvitacion(int id)
        {
            var codigoInvitacion = await _context.CodigosInvitaciones.FindAsync(id);
            if (codigoInvitacion == null)
            {
                return NotFound();
            }

            _context.CodigosInvitaciones.Remove(codigoInvitacion);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CodigoInvitacionExists(int id)
        {
            return _context.CodigosInvitaciones.Any(e => e.Id == id);
        }
    }
}
