﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Alphtmost.Modelos;

namespace Alphtmost.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GruposPremiumsController : ControllerBase
    {
        private readonly DbContext _context;

        public GruposPremiumsController(DbContext context)
        {
            _context = context;
        }

        // GET: api/GruposPremiums
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GrupoPremium>>> GetGrupoPremium()
        {
            return await _context.GruposPremiums.ToListAsync();
        }

        // GET: api/GruposPremiums/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GrupoPremium>> GetGrupoPremium(int id)
        {
            var grupoPremium = await _context.GruposPremiums.FindAsync(id);

            if (grupoPremium == null)
            {
                return NotFound();
            }

            return grupoPremium;
        }

        // PUT: api/GruposPremiums/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutGrupoPremium(int id, GrupoPremium grupoPremium)
        {
            if (id != grupoPremium.Id)
            {
                return BadRequest();
            }

            _context.Entry(grupoPremium).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GrupoPremiumExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/GruposPremiums
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<GrupoPremium>> PostGrupoPremium(GrupoPremium grupoPremium)
        {
            _context.GruposPremiums.Add(grupoPremium);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetGrupoPremium", new { id = grupoPremium.Id }, grupoPremium);
        }

        // DELETE: api/GruposPremiums/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGrupoPremium(int id)
        {
            var grupoPremium = await _context.GruposPremiums.FindAsync(id);
            if (grupoPremium == null)
            {
                return NotFound();
            }

            _context.GruposPremiums.Remove(grupoPremium);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool GrupoPremiumExists(int id)
        {
            return _context.GruposPremiums.Any(e => e.Id == id);
        }
    }
}
