﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Alphtmost.Modelos;

namespace Alphtmost.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BibliografiasController : ControllerBase
    {
        private readonly DbContext _context;

        public BibliografiasController(DbContext context)
        {
            _context = context;
        }

        // GET: api/Bibliografias
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Bibliografia>>> GetBibliografias()
        {
            return await _context.Bibliografias.ToListAsync();
        }

        // GET: api/Bibliografias/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Bibliografia>> GetBibliografia(int id)
        {
            var bibliografia = await _context.Bibliografias.FindAsync(id);

            if (bibliografia == null)
            {
                return NotFound();
            }

            return bibliografia;
        }

        // PUT: api/Bibliografias/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBibliografia(int id, Bibliografia bibliografia)
        {
            if (id != bibliografia.Id)
            {
                return BadRequest();
            }

            _context.Entry(bibliografia).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BibliografiaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Bibliografias
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Bibliografia>> PostBibliografia(Bibliografia bibliografia)
        {
            _context.Bibliografias.Add(bibliografia);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetBibliografia", new { id = bibliografia.Id }, bibliografia);
        }

        // DELETE: api/Bibliografias/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBibliografia(int id)
        {
            var bibliografia = await _context.Bibliografias.FindAsync(id);
            if (bibliografia == null)
            {
                return NotFound();
            }

            _context.Bibliografias.Remove(bibliografia);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool BibliografiaExists(int id)
        {
            return _context.Bibliografias.Any(e => e.Id == id);
        }
    }
}
