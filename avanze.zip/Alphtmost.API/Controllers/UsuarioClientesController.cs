﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Alphtmost.Modelos;

namespace Alphtmost.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioClientesController : ControllerBase
    {
        private readonly DbContext _context;

        public UsuarioClientesController(DbContext context)
        {
            _context = context;
        }

        // GET: api/UsuarioClientes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<UsuarioCliente>>> GetUsuarioCliente()
        {
            return await _context.UsuariosClientes.ToListAsync();
        }

        // GET: api/UsuarioClientes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<UsuarioCliente>> GetUsuarioCliente(int id)
        {
            var usuarioCliente = await _context.UsuariosClientes.FindAsync(id);

            if (usuarioCliente == null)
            {
                return NotFound();
            }

            return usuarioCliente;
        }

        // GET: api/UsuarioClientes/email/{email}
        [HttpGet("email/{email}")]
        public async Task<ActionResult<UsuarioCliente>> GetUsuarioClienteByEmail(string email)
        {
            if (string.IsNullOrEmpty(email))
            {
                return BadRequest("El correo electrónico no puede ser nulo o vacío.");
            }

            var usuarioCliente = await _context.UsuariosClientes.FirstOrDefaultAsync(u => u.Email == email);

            if (usuarioCliente == null)
            {
                return NotFound($"Usuario con el correo {email} no encontrado.");
            }

            return usuarioCliente;
        }

        // POST: api/UsuarioClientes
        [HttpPost]
        public async Task<ActionResult<UsuarioCliente>> PostUsuarioCliente(UsuarioCliente usuarioCliente)
        {
            // Asegúrate de que el Id no esté asignado (debe ser 0 para que la BD lo autogenere)
            usuarioCliente.Id = 0;

            _context.UsuariosClientes.Add(usuarioCliente);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetUsuarioCliente), new { id = usuarioCliente.Id }, usuarioCliente);
        }

        // PUT: api/UsuarioClientes/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUsuarioCliente(int id, UsuarioCliente usuarioCliente)
        {
            if (id != usuarioCliente.Id)
            {
                return BadRequest();
            }

            _context.Entry(usuarioCliente).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UsuarioClienteExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/UsuarioClientes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUsuarioCliente(int id)
        {
            var usuarioCliente = await _context.UsuariosClientes.FindAsync(id);
            if (usuarioCliente == null)
            {
                return NotFound();
            }

            _context.UsuariosClientes.Remove(usuarioCliente);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool UsuarioClienteExists(int id)
        {
            return _context.UsuariosClientes.Any(e => e.Id == id);
        }
    }
}