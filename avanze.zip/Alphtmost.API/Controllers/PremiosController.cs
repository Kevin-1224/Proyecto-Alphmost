﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Alphtmost.Modelos;

namespace Alphtmost.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PremiosController : ControllerBase
    {
        private readonly DbContext _context;

        public PremiosController(DbContext context)
        {
            _context = context;
        }

        // GET: api/Premios
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Premio>>> GetPremio()
        {
            return await _context.Premios.ToListAsync();
        }

        // GET: api/Premios/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Premio>> GetPremio(int id)
        {
            var premio = await _context.Premios.FindAsync(id);

            if (premio == null)
            {
                return NotFound();
            }

            return premio;
        }

        // PUT: api/Premios/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPremio(int id, Premio premio)
        {
            if (id != premio.Id)
            {
                return BadRequest();
            }

            _context.Entry(premio).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PremioExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Premios
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Premio>> PostPremio(Premio premio)
        {
            _context.Premios.Add(premio);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPremio", new { id = premio.Id }, premio);
        }

        // DELETE: api/Premios/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePremio(int id)
        {
            var premio = await _context.Premios.FindAsync(id);
            if (premio == null)
            {
                return NotFound();
            }

            _context.Premios.Remove(premio);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool PremioExists(int id)
        {
            return _context.Premios.Any(e => e.Id == id);
        }
    }
}
