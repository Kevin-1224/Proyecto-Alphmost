﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Alphtmost.Modelos;

namespace Alphtmost.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArtistasClientesController : ControllerBase
    {
        private readonly DbContext _context;

        public ArtistasClientesController(DbContext context)
        {
            _context = context;
        }

        // GET: api/ArtistasClientes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ArtistaCliente>>> GetArtistaCliente()
        {
            return await _context.ArtistasClientes.ToListAsync();
        }

        // GET: api/ArtistasClientes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ArtistaCliente>> GetArtistaCliente(int id)
        {
            var artistaCliente = await _context.ArtistasClientes.FindAsync(id);

            if (artistaCliente == null)
            {
                return NotFound();
            }

            return artistaCliente;
        }

        // GET: api/UsuarioClientes/email/{email}
        [HttpGet("email/{email}")]
        public async Task<ActionResult<ArtistaCliente>> GetArtistaClienteByEmail(string email)
        {
            if (string.IsNullOrEmpty(email))
            {
                return BadRequest("El correo electrónico no puede ser nulo o vacío.");
            }

            try
            {
                var artistaCliente = await _context.ArtistasClientes
                        .FirstOrDefaultAsync(u => u.Email == email);

                if (artistaCliente == null)
                {
                    return NotFound($"Usuario con el correo {email} no encontrado.");
                }

                return artistaCliente;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al obtener el usuario con el correo {email}: {ex.Message}");
                return StatusCode(500, "Error interno del servidor. No se pudo procesar la solicitud.");
            }
        }


        // PUT: api/ArtistasClientes/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutArtistaCliente(int id, ArtistaCliente artistaCliente)
        {
            if (id != artistaCliente.Id)
            {
                return BadRequest();
            }

            _context.Entry(artistaCliente).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ArtistaClienteExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ArtistasClientes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<ArtistaCliente>> PostArtistaCliente(ArtistaCliente artistaCliente)
        {
            _context.ArtistasClientes.Add(artistaCliente);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetArtistaCliente", new { id = artistaCliente.Id }, artistaCliente);
        }

        // DELETE: api/ArtistasClientes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteArtistaCliente(int id)
        {
            var artistaCliente = await _context.ArtistasClientes.FindAsync(id);
            if (artistaCliente == null)
            {
                return NotFound();
            }

            _context.ArtistasClientes.Remove(artistaCliente);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ArtistaClienteExists(int id)
        {
            return _context.ArtistasClientes.Any(e => e.Id == id);
        }
    }
}
