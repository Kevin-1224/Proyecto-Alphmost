﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Alphtmost.Enums.Enums;

namespace Alphtmost.Modelos
{ 

    public class Transaccion
    {
        [Key]public int Id { get; set; }
        public int PagoId { get; set; }
        public EstadoTransaccion EstadoTransaccion { get; set; }  
        public DateTime FechaTransaccion { get; set; } = DateTime.Now;
        public string DetalleTransaccion { get; set; } 
        [Required] public double Monto { get; set; }
        public Pago? Pago { get; set; }
    }
}
