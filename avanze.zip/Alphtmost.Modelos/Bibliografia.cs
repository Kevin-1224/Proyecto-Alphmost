﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Alphtmost.Modelos
{
    public class Bibliografia
    {
        [Key] public int Id { get; set; }
        public string Biografia { get; set; }
        public string EstiloMusical { get; set; }
        public string Discografia { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public string PaisOrigen { get; set; }
        public int? ArtistaId { get; set; }
        public Artista? Artista { get; set; }
        public int? ArtistaClienteId { get; set; }
        public ArtistaCliente? ArtistaCliente { get; set; }
        public List<Premio>? Premios { get; set; } 
    }
}
