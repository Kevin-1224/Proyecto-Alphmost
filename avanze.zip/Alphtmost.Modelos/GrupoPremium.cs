﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Alphtmost.Enums.Enums;

namespace Alphtmost.Modelos
{
    public class GrupoPremium
    {
        [Key]public int Id { get; set; }
        [Required]public int UsuarioClienteId { get; set; } // Usuario que pagó y es el admin del grupo
        [Required] public string CodigoInvitacionUnico { get; set; } // Código único para el grupo
        public DateTime FechaCreacion { get; set; } = DateTime.Now; // Fecha de creación del grupo
        [Required]public TipoPlanPremium TipoPlan { get; set; } // Familiar o Empresarial
        public int LimiteMiembros { get; set; } // Límite de miembros en el grupo (5 para familiar, 30 para empresarial)
        public List<UsuarioCliente>? Miembros { get; set; } // Miembros del grupo invitados 
    }
}
