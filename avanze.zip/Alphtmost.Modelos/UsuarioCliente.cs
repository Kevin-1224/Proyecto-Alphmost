﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;
using static Alphtmost.Enums.Enums;

namespace Alphtmost.Modelos
{


    public class UsuarioCliente
    {
        [Key] public int Id { get; set; }
        [Required] public string Nombre { get; set; }
        [Required] public string Apellido { get; set; }
        [Required][EmailAddress] public string Email { get; set; }
        [Required] public string ContraseñaHash { get; set; }
        [Required] public Genero Genero { get; set; }
        public bool EsPremium { get; set; } = false;
        [Required] public DateTime FechaNacimiento { get; set; }
        public DateTime FechaRegistro { get; set; } = DateTime.Now;
        public DateTime? FechaVencimientoPremium { get; set; }
        public int? GrupoPremiumId { get; set; } 
        public GrupoPremium? GrupoPremium { get; set; } 
        public List<Pago>? Pagos { get; set; }
        public Perfil? Perfil { get; set; }
    }
}
