﻿using BCrypt.Net;
using System;

namespace cripcontraseña
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingresa la contraseña a hashear: ");
            string password = Console.ReadLine();

            // Generar el hash usando BCrypt.Net
            string hash = BCrypt.Net.BCrypt.HashPassword(password);

            Console.WriteLine("Hash generado:");
            Console.WriteLine(hash);
        }
    }
}
